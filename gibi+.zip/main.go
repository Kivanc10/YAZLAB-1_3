package main

import "YAZLAB3MONGO/route"

func main() {
	// client := db.ConnectToMongoDb()
	route.HandleRequest()
}
