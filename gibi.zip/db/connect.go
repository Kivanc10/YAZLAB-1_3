package db

import (
	"YAZLAB3MONGO/student"
	"bytes"
	"context"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"mime/multipart"
	"net/url"
	"os"
	"time"

	"github.com/dgrijalva/jwt-go"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/gridfs"
	"go.mongodb.org/mongo-driver/mongo/options"

	"golang.org/x/crypto/bcrypt"
)

var mySigningKey = []byte("captainjacksparrowsayshi")

func CreateToken(name, lastname, number string) (string, error) {
	var err error
	//Creating Access Token
	os.Setenv("ACCESS_SECRET", string(mySigningKey)) //this should be in an env file
	atClaims := jwt.MapClaims{}
	atClaims["authorized"] = true
	//atClaims["user_id"] = userId
	atClaims["user_name"] = name
	atClaims["last_name"] = lastname
	atClaims["number"] = number
	atClaims["exp"] = time.Now().Add(time.Minute * 1500).Unix()
	at := jwt.NewWithClaims(jwt.SigningMethodHS256, atClaims)
	token, err := at.SignedString([]byte(os.Getenv("ACCESS_SECRET")))
	if err != nil {
		return "", errors.New("an error occured during the create token")
	}
	fmt.Println("jwt map --> ", atClaims)
	return token, nil
}

func ConnectToMongoDb() *mongo.Client {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	client, err := mongo.Connect(ctx, options.Client().ApplyURI("mongodb://127.0.0.1:27017/"))
	if err != nil {
		panic(err)
	}
	err = client.Ping(ctx, nil) // to check there is an error caused by interrupting

	if err != nil {
		panic(err)
	}
	return client
}

func hashPassword(password string) (string, error) {
	bytes, err := bcrypt.GenerateFromPassword([]byte(password), 14)
	return string(bytes), err
}

func checkPassword(password, hash string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
	return err == nil
}

func isAlreadyExist(name string, client *mongo.Client) (student.Student, bool) {
	collection := client.Database("User").Collection("token")
	temp := bson.M{"name": bson.M{"$eq": name}}
	result := student.Student{}
	err := collection.FindOne(context.Background(), temp).Decode(&result)
	if err != nil {
		return student.Student{}, false
	} else {
		return result, true
	}

}

func insertInto(client *mongo.Client, stndt student.Student) error {
	collection := client.Database("User").Collection("token")
	hash, err := hashPassword(stndt.Password)
	if err != nil {
		log.Fatal("an error occured during hashed the password")
	}
	//tempPswrd := stndt.Password
	stndt.Password = hash // --

	addTokenToPerson(&stndt)
	//stndt.Password = tempPswrd
	toSave, err := bson.Marshal(stndt)
	if err != nil {
		log.Fatal("an error occured during the marshalling")
		return err
	}
	if _, result := isAlreadyExist(stndt.Name, client); !result {
		res, err := collection.InsertOne(context.Background(), toSave)
		if err != nil {
			panic(err)
		}
		id := res.InsertedID
		fmt.Println("id --> ", id)
		return nil
	} else {
		return errors.New("The user is already exist")
	}
}

func addTokenToPerson(stdnt *student.Student) string {
	token, err := CreateToken(stdnt.Name, stdnt.Lastname, stdnt.Number)
	if err != nil {
		log.Fatal("An error occured during the produce token ", err)
	}
	temp := student.Token{Context: token}
	stdnt.Tokens = append(stdnt.Tokens, temp)
	os.Setenv("Token", stdnt.Tokens[0].Context)
	os.Setenv("userName", stdnt.Name)
	return token
}

func AddUser(username, lastname, password, number, schoolType string, client *mongo.Client) (*student.Student, error) {
	var stndt student.Student
	stndt.Name = username
	stndt.Lastname = lastname
	stndt.Password = password
	stndt.Number = number
	stndt.Type = schoolType
	addTokenToPerson(&stndt)
	if err := insertInto(client, stndt); err != nil {
		log.Println("an error occured during the inserting ", err)
		return &student.Student{}, err
	}
	return &stndt, nil
}

func Login(password, number string, client *mongo.Client) (*student.Student, error) {
	collection := client.Database("User").Collection("token")
	filter := bson.M{"number": bson.M{"$eq": number}}
	var stndt student.Student
	err := collection.FindOne(context.Background(), filter).Decode(&stndt)
	if err != nil {
		return &student.Student{}, errors.New("Önce kayıt ol")
	} else {
		if !checkPassword(password, stndt.Password) {
			return &student.Student{}, errors.New("Parolan YANLIŞ")
		}
		addTokenToPerson(&stndt)
		err = addTokenForLogin(client, &stndt)
		if err != nil {
			return &student.Student{}, errors.New("Error occured when updating token")
		}
		return &stndt, nil
	}
}

func addTokenForLogin(client *mongo.Client, stdnt *student.Student) error {
	collection := client.Database("User").Collection("token")
	filter := bson.M{"name": stdnt.Name}
	update := bson.M{"$set": bson.M{
		"tokens": stdnt.Tokens}}
	res := collection.FindOneAndUpdate(context.Background(), filter, update)
	resDecoded := student.Student{}
	err := res.Decode(&resDecoded)
	return err
}

func SignInForAdmin(username, password string) *student.Admin {
	var admin student.Admin

	admin.Name = username
	admin.Password = password
	return &admin
}

func GetAllUsers(client *mongo.Client) []bson.M {
	collection := client.Database("User").Collection("token")

	cursor, err := collection.Find(context.Background(), bson.M{})

	if err != nil {
		log.Fatal(err)
	}

	var students_b []bson.M

	if err = cursor.All(context.Background(), &students_b); err != nil {
		log.Fatal(err)
	}
	return students_b
}

func DeleteUser(client *mongo.Client, name string) error {
	collection := client.Database("User").Collection("token")
	filter := bson.M{"name": name}
	res := collection.FindOneAndDelete(context.Background(), filter)
	resDecoded := student.Student{}
	err := res.Decode(&resDecoded)
	if err != nil {
		log.Printf("an error occured during the delete user")
		return err
	}
	return nil

}

func DeleteUsersAllDocsWithUserName(client *mongo.Client, givenName string) {
	collection := client.Database("User").Collection("token")
	filter1 := bson.M{"name": givenName}
	res := collection.FindOne(context.Background(), filter1)
	var user student.Student
	err := res.Decode(&user)
	if err != nil {
		log.Fatal(err)
	}
	collection = client.Database("User").Collection("fs.files")
	cursor, err := collection.Find(context.Background(), bson.M{})
	if err != nil {
		log.Fatal(err)
	}
	var docs []bson.M
	if err = cursor.All(context.Background(), &docs); err != nil {
		log.Fatal(err)
	}
	for _, i := range docs {
		var temp student.Doc
		bsonBytes, _ := bson.Marshal(i)
		bson.Unmarshal(bsonBytes, &temp)
		if temp.MetaData.OwnerName == user.Name {
			//tempDoc = append(tempDoc, temp)
			fmt.Println("doc filename --> ", temp.FileName)
			fmt.Println("evet query is active")
			collection.FindOneAndDelete(context.Background(), bson.M{"filename": temp.FileName})
		}
	}

}

func UpdateUserByItself(client *mongo.Client, givenName, username, lastname, number, typeOf string) *student.Student {
	collection := client.Database("User").Collection("token")
	filter := bson.M{"name": bson.M{"$eq": givenName}}
	res := collection.FindOne(context.Background(), filter)
	var currentUser student.Student
	if err := res.Decode(&currentUser); err != nil {
		log.Fatal(err)
		return &student.Student{}
	}
	//fmt.Println("got username --> ", username)
	newStdnt := student.Student{}
	newStdnt.Name = username
	newStdnt.Lastname = lastname
	newStdnt.Number = number
	newStdnt.Type = typeOf
	newStdnt.Tokens = currentUser.Tokens
	newStdnt.Password = currentUser.Password
	fmt.Println("intermediate stdnt -> ", newStdnt)
	res = collection.FindOneAndUpdate(context.Background(), filter, bson.M{
		"$set": bson.M{
			"name":     newStdnt.Name,
			"lastname": newStdnt.Lastname,
			"number":   newStdnt.Number,
			"type":     newStdnt.Type,
		}})
	resDecoded := student.Student{}
	err := res.Decode(&resDecoded)
	if err != nil {
		panic(err)
	}
	//	os.Setenv("userName", newStdnt.Name)
	//	os.Setenv("userName",)
	// change docs name
	// -------------------------------------------------

	collection = client.Database("User").Collection("fs.files")
	var allDocs []bson.M
	cursor, err := collection.Find(context.Background(), bson.M{})
	if err != nil {
		log.Fatal(err)
	}
	if err = cursor.All(context.Background(), &allDocs); err != nil {
		log.Fatal(err)
	}
	var toReturn []student.Doc
	fmt.Println("allDocs --> ", allDocs)
	//bsonBytes, _ := bson.Marshal(allDocs)
	//bson.Unmarshal(bsonBytes, &toReturn)

	fmt.Println("toReturn data -> ", toReturn)
	for _, i := range allDocs {
		var temp student.Doc
		bsonBytes, _ := bson.Marshal(i)
		bson.Unmarshal(bsonBytes, &temp)
		fmt.Println("temp student ----> ", temp)
		if temp.MetaData.OwnerName == os.Getenv("userName") {
			filter := bson.M{"filename": temp.FileName}
			collection.FindOneAndUpdate(context.Background(), filter, bson.M{
				"$set": bson.M{
					"length":     temp.Length,
					"chunkSize":  temp.ChunkSize,
					"uploadDate": temp.UploadDate,
					"fileName":   temp.FileName,
					"metadata": bson.M{
						"owner_name":  newStdnt.Name,
						"deploy_date": temp.MetaData.DeployDate,
					}}})
			// "$set": bson.M{
			// 	"metadata": bson.M{"owner_name": os.Getenv("userName"), "deploy_date": temp.MetaData.DeployDate},
			// }})
		}
	}
	// -------------------------------------------------
	fmt.Println("new stdnt ", resDecoded)
	os.Setenv("userName", newStdnt.Name)
	fmt.Println("saved set env name --> ", os.Getenv("userName"))
	return &resDecoded

}

func UpdateUserByAdmin(client *mongo.Client, givenId, username, lastname, number, typeOf string) *student.Student {
	collection := client.Database("User").Collection("token")
	hexByte, err := primitive.ObjectIDFromHex(givenId)
	if err != nil {
		panic(err)
	}

	filter1 := bson.M{"_id": bson.M{"$eq": hexByte}}
	res := collection.FindOne(context.Background(), filter1)
	var stdnt student.Student
	if err := res.Decode(&stdnt); err != nil {
		log.Fatal(err)
		return &student.Student{}
	}
	fmt.Println("founded user ", stdnt)
	newStdnt := student.Student{}
	newStdnt.Name = username
	newStdnt.Lastname = lastname
	newStdnt.Number = number
	newStdnt.Type = typeOf
	newStdnt.Tokens = stdnt.Tokens
	newStdnt.Password = stdnt.Password
	res = collection.FindOneAndUpdate(context.Background(), filter1, bson.M{
		"$set": bson.M{
			"name":     newStdnt.Name,
			"lastname": newStdnt.Lastname,
			"number":   newStdnt.Number,
			"type":     newStdnt.Type,
		}})

	resDecoded := student.Student{}
	err = res.Decode(&resDecoded)
	if err != nil {
		panic(err)
	}
	fmt.Println("new stdnt ", resDecoded)
	// to update users docs
	collection = client.Database("User").Collection("fs.files")
	var allDocs []bson.M
	cursor, err := collection.Find(context.Background(), bson.M{})
	if err != nil {
		log.Fatal(err)
	}
	if err = cursor.All(context.Background(), &allDocs); err != nil {
		log.Fatal(err)
	}
	//var toReturn []student.Doc
	for _, i := range allDocs {
		var temp student.Doc
		bsonBytes, _ := bson.Marshal(i)
		bson.Unmarshal(bsonBytes, &temp)
		if temp.MetaData.OwnerName == stdnt.Name {
			fmt.Println("EVET BIR TANE VARRRR")
			filter := bson.M{"filename": temp.FileName}
			collection.FindOneAndUpdate(context.Background(), filter, bson.M{
				"$set": bson.M{
					"length":     temp.Length,
					"chunkSize":  temp.ChunkSize,
					"uploadDate": temp.UploadDate,
					"filename":   temp.FileName,
					"metadata": bson.M{
						"owner_name":  newStdnt.Name,
						"deploy_date": temp.MetaData.DeployDate,
					}}})
		}
	}
	return &resDecoded
}

var deploy_date string

func UploadFile(client *mongo.Client, file multipart.File, filename, owner string) { //a multipart.File
	//data, err := ioutil.ReadFile(file)
	data, err := ioutil.ReadAll(file)
	if err != nil {
		log.Fatal(err)
	}
	//collection := client.Database("User").Collection("pdfs")
	bucket, err := gridfs.NewBucket(
		client.Database("User"),
	)
	if err != nil {
		log.Fatal(err)
		os.Exit(1)
	}
	deploy_date = "2018_2019_BAHAR" // --
	lesson_name := "programming"
	//keywords := []string{"", "", ""}
	uploadOpts := options.GridFSUpload().
		//SetMetadata(bson.D{{"owner_name", owner}, {"deploy_date", deploy_date}}) //, {"deploy_date", deploy_date}
		SetMetadata(bson.M{
			"owner_name":   owner,
			"deploy_date":  deploy_date, // --
			"project_name": "project_1", // --
			"keywords": []student.KeyWord{
				{Word: "keyword1"},
				{Word: "keyword2"},
				//{Word: "keyword3"},
			},
			"lesson_name": lesson_name,
		})
	uploadStream, err := bucket.OpenUploadStream(
		filename,
		uploadOpts,
	)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	defer uploadStream.Close()

	fileSize, err := uploadStream.Write(data)
	if err != nil {
		log.Fatal(err)
		os.Exit(1)
	}

	log.Printf("Write file to DB was successful. File size: %d M\n", fileSize)

}

func DownloadDocs(client *mongo.Client, filename string) { //, filename string
	collection := client.Database("User").Collection("fs.files")
	//var results bson.M
	cursor, err := collection.Find(context.Background(), bson.M{})
	if err != nil {
		log.Fatal(err)
	}
	var docs []bson.M

	if err = cursor.All(context.Background(), &docs); err != nil {
		log.Fatal(err)
	}
	fmt.Println("results --> ", docs)
	bucket, _ := gridfs.NewBucket(
		client.Database("User"),
	)
	var buf bytes.Buffer
	dStream, err := bucket.DownloadToStreamByName(filename, &buf)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("File size to download: %v\n", dStream)
	ioutil.WriteFile("./static/images/"+filename, buf.Bytes(), 0600)

}
func DisplayImageById(client *mongo.Client, givenId string) string { // filename
	collection := client.Database("User").Collection("fs.files")
	hexByte, err := primitive.ObjectIDFromHex(givenId)
	if err != nil {
		panic(err)
	}
	filter1 := bson.M{"_id": bson.M{"$eq": hexByte}}
	res := collection.FindOne(context.Background(), filter1)
	var doc student.Doc
	if err := res.Decode(&doc); err != nil { // to get doc object
		log.Fatal(err)
	}
	bucket, _ := gridfs.NewBucket(
		client.Database("User"),
	)
	var buf bytes.Buffer
	dStream, err := bucket.DownloadToStreamByName(doc.FileName, &buf)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("File size to download: %v\n", dStream)
	ioutil.WriteFile("./static/images/"+doc.FileName, buf.Bytes(), 0600)
	return doc.FileName
}

func GetAllDocsByAdmin(client *mongo.Client, myUrl string) []bson.M {
	collection := client.Database("User").Collection("fs.files")
	u, err := url.Parse(myUrl)
	if err != nil {
		log.Fatal(err)
	}
	var docs []bson.M
	m, _ := url.ParseQuery(u.RawQuery)
	if len(m) == 0 { // there is no query
		cursor, err := collection.Find(context.Background(), bson.M{})
		if err != nil {
			log.Fatal(err)
		}
		if err = cursor.All(context.Background(), &docs); err != nil {
			log.Fatal(err)
		}
		var tempDoc []student.Doc
		for _, i := range docs {
			var temp student.Doc
			bsonBytes, _ := bson.Marshal(i)
			bson.Unmarshal(bsonBytes, &temp)
			tempDoc = append(tempDoc, temp)
		}
		if tempDoc == nil {
			docs = nil
		} else {
			docs = nil
			for _, i := range tempDoc {
				var temp bson.M
				data, err := bson.Marshal(i)
				if err != nil {
					log.Fatal(err)
				}
				err = bson.Unmarshal(data, &temp)
				if err != nil {
					log.Fatal(err)
				}
				docs = append(docs, temp)
			}
		}

	} else { // there is least one query
		for k := range m {
			var allDocs []bson.M
			cursor, err := collection.Find(context.Background(), bson.M{})
			if err != nil {
				log.Fatal(err)
			}
			if err = cursor.All(context.Background(), &allDocs); err != nil {
				log.Fatal(err)
			}
			var toReturn []student.Doc
			for _, i := range allDocs {
				var temp student.Doc
				bsonBytes, _ := bson.Marshal(i)
				bson.Unmarshal(bsonBytes, &temp)
				if (k == "deploy_date") && (temp.MetaData.DeployDate == m[k][0]) {
					//filter := bson.M{"filename": temp.FileName}
					toReturn = append(toReturn, temp)
				}
				if (k == "project_name") && temp.MetaData.ProjectName == m[k][0] {
					toReturn = append(toReturn, temp)
				}
				if (k == "keywords") && student.IsInsideOfKey(temp.MetaData.KeyWords, m[k][0]) {
					toReturn = append(toReturn, temp)
				}
				if (k == "lesson_name") && temp.MetaData.Lesson == m[k][0] {
					toReturn = append(toReturn, temp)
				}
				if (k == "owner_name") && temp.MetaData.OwnerName == m[k][0] {
					toReturn = append(toReturn, temp)
				}
			}
			//
			for _, i := range toReturn {
				var temp bson.M
				data, err := bson.Marshal(i)
				if err != nil {
					log.Fatal(err)
				}
				err = bson.Unmarshal(data, &temp)
				if err != nil {
					log.Fatal(err)
				}
				docs = append(docs, temp)
			}
		}
	}
	return docs
}

func DeleteUsersAllDocsById(client *mongo.Client, givenId string) {
	collection := client.Database("User").Collection("token")
	hexByte, err := primitive.ObjectIDFromHex(givenId)
	if err != nil {
		log.Fatal(err)
	}
	res := collection.FindOne(context.Background(), bson.M{"_id": hexByte})

	var user student.Student
	err = res.Decode(&user)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("given user name --> ", user.Name, " ", user.Lastname)

	// if err = cursor.All(context.Background(), &user); err != nil {
	// 	log.Fatal(err)
	// }
	collection = client.Database("User").Collection("fs.files")
	cursor, err := collection.Find(context.Background(), bson.M{})
	if err != nil {
		log.Fatal(err)
	}
	var docs []bson.M
	if err = cursor.All(context.Background(), &docs); err != nil {
		log.Fatal(err)
	}
	//var tempDoc []student.Doc
	for _, i := range docs {
		var temp student.Doc
		bsonBytes, _ := bson.Marshal(i)
		bson.Unmarshal(bsonBytes, &temp)
		if temp.MetaData.OwnerName == user.Name {
			//tempDoc = append(tempDoc, temp)
			fmt.Println("doc filename --> ", temp.FileName)
			fmt.Println("evet query is active")
			collection.FindOneAndDelete(context.Background(), bson.M{"filename": temp.FileName})
		}
	}

}

func AccessAllDocs(client *mongo.Client, myUrl string) []bson.M {
	collection := client.Database("User").Collection("fs.files")
	fmt.Println("ownername --> ", os.Getenv("userName"))
	u, err := url.Parse(myUrl)
	if err != nil {
		log.Fatal(err)
	}
	var docs []bson.M
	m, _ := url.ParseQuery(u.RawQuery)

	if len(m) == 0 {
		cursor, err := collection.Find(context.Background(), bson.M{}) //bson.M{"metadata": bson.M{}}
		if err != nil {
			log.Fatal(err)
		}
		//var docs []student.Doc
		if err = cursor.All(context.Background(), &docs); err != nil {
			log.Fatal(err)
		}
		var tempDoc []student.Doc
		for _, i := range docs {
			var temp student.Doc
			bsonBytes, _ := bson.Marshal(i)
			bson.Unmarshal(bsonBytes, &temp)
			if temp.MetaData.OwnerName == os.Getenv("userName") {
				fmt.Println("hereeeeeeeeeeeeeeeeeeeeeee")
				tempDoc = append(tempDoc, temp)
			}
		}
		if tempDoc == nil {
			docs = nil
		} else {
			docs = nil
			fmt.Println("tempdoc --> ", tempDoc)
			for _, i := range tempDoc {
				var temp bson.M
				data, err := bson.Marshal(i)
				if err != nil {
					log.Fatal(err)
				}
				err = bson.Unmarshal(data, &temp)
				if err != nil {
					log.Fatal(err)
				}
				docs = append(docs, temp)
			}
		}
		fmt.Println("new docs --> ", docs)
		//return docs
	} else {
		fmt.Println("query is active")
		fmt.Println("m -->", m)
		for k := range m {
			fmt.Println("I'm in")
			fmt.Println("k -->", k)
			var allDocs []bson.M
			cursor, err := collection.Find(context.Background(), bson.M{})
			if err != nil {
				log.Fatal(err)
			}
			if err = cursor.All(context.Background(), &allDocs); err != nil {
				log.Fatal(err)
			}
			var toReturn []student.Doc
			for _, i := range allDocs {
				var temp student.Doc
				bsonBytes, _ := bson.Marshal(i)
				bson.Unmarshal(bsonBytes, &temp)
				if (temp.MetaData.OwnerName == os.Getenv("userName")) && (k == "deploy_date") && (temp.MetaData.DeployDate == m[k][0]) {
					//filter := bson.M{"filename": temp.FileName}
					toReturn = append(toReturn, temp)
				}
				if (temp.MetaData.OwnerName == os.Getenv("userName")) && (k == "project_name") && temp.MetaData.ProjectName == m[k][0] {
					toReturn = append(toReturn, temp)
				}
				if (temp.MetaData.OwnerName == os.Getenv("userName")) && (k == "keywords") && student.IsInsideOfKey(temp.MetaData.KeyWords, m[k][0]) {
					toReturn = append(toReturn, temp)
				}
				if (temp.MetaData.OwnerName == os.Getenv("userName")) && (k == "lesson_name") && temp.MetaData.Lesson == m[k][0] {
					toReturn = append(toReturn, temp)
				}
				if (temp.MetaData.OwnerName == os.Getenv("userName")) && (k == "owner_name") && temp.MetaData.OwnerName == m[k][0] {
					toReturn = append(toReturn, temp)
				}
			}
			//fmt.Println(toReturn)
			// doc to bson
			for _, i := range toReturn {
				var temp bson.M
				data, err := bson.Marshal(i)
				if err != nil {
					log.Fatal(err)
				}
				err = bson.Unmarshal(data, &temp)
				if err != nil {
					log.Fatal(err)
				}
				docs = append(docs, temp)
			}
			//doc to bson
		}
		//return nil
	}
	return docs
}

func DeleteWithAdmin(client *mongo.Client, givenId string) {
	collection := client.Database("User").Collection("token")
	hexByte, err := primitive.ObjectIDFromHex(givenId)
	if err != nil {
		panic(err)
	}

	filter1 := bson.M{"_id": bson.M{"$eq": hexByte}}
	res := collection.FindOne(context.Background(), filter1)

	var stdnt student.Student
	if err := res.Decode(&stdnt); err != nil {
		log.Fatal(err)
		//return &student.Student{}
	}

	res = collection.FindOneAndDelete(context.Background(), filter1)

}
